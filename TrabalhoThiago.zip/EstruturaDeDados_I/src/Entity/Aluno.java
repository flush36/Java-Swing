package Entity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import arquivo.EscreverArquivo;
import arquivo.LerArquivos;

public class Aluno {

	private int matricula;
	private String nome;
	private String curso;
	static List<Aluno> listaAluno = new ArrayList<Aluno>();
	static EscreverArquivo arquivo = new EscreverArquivo();
	static LerArquivos ler = new LerArquivos();
	
	public Aluno(int matricula, String nome, String curso) {
		this.matricula = matricula;
		this.nome = nome;
		this.curso = curso;
	}
	
	
	
	//Adiciona todos os cursos no txt
			public static void adicionaAluno(Aluno aluno) throws IOException{
				if(!aluno.equals("")){
					listaAluno.add(aluno);
					arquivo.EscreveEmAluno(listaAluno);
					listaAluno.remove(aluno);
					System.out.println("Dados adicionados com sucesso!");
				}else{
					System.out.println("Preencha os dados do aluno.");
				}
			}
			
			//Lista todos os cursos no txt
			public static String ListarAlunos() throws IOException{
				return ler.LerEmAluno();
				 
			}
			
			
			//Buscar por ID
			public static String BuscarID(CharSequence id) throws IOException{
				if(ler.LerEmAluno().contains(id)){
					System.out.println("Contem");
					return (String) id;
				}else {
					System.out.println("Nao contem o id que foi passado");
					return null;
				}
				
				
			}
	
	

	
	@Override
	public String toString() {
		return "Matricula: " + this.matricula + "  Nome: " + this.nome + "  Curso: " + this.curso;
	}
	
	
	// GETTERS AND SETTERS

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public List<Aluno> getListaAluno() {
		return listaAluno;
	}
	
	
	
	
}
