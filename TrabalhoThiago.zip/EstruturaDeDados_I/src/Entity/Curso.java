package Entity;



import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import arquivo.EscreverArquivo;
import arquivo.LerArquivos;



public class Curso {

	private int id;
	private String nome;
	static ArrayList<Curso> listaCurso = new ArrayList<Curso>();
	static EscreverArquivo arquivo = new EscreverArquivo();
	static LerArquivos ler = new LerArquivos();
	
	
	
	
	
	
	public Curso(int id, String nome) {
		this.id = id;
		this.nome = nome;
	}
	
	//Adiciona todos os cursos no txt
	public static void adicionaCurso(Curso curso) throws IOException{
		if(!curso.equals("")){
			listaCurso.add(curso);
			arquivo.EscreveEmCurso(listaCurso);
			listaCurso.remove(curso);
			System.out.println("Dados adicionados com sucesso!");
		}else{
			System.out.println("Preencha os dados do curso.");
		}
	}
	
	//Lista todos os cursos no txt
	public static String ListarCursos() throws IOException{
		return ler.LerEmCurso();
	}
	
	
	//Buscar por ID
	public static String BuscarID(CharSequence id) throws IOException{
		if(ler.LerEmCurso().contains(id)){
			System.out.println("Contem");
			return (String) id;
		}else {
			System.out.println("Nao contem o id que foi passado");
			return null;
		}
		
		
	}
	
	


	//ToString
	@Override
	public String toString() {
		return "ID: " + this.id + "   Nome: " + nome;
	}
	
//  GETTERS AND SETTERS
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public static List<Curso> getListaCurso() {
		return listaCurso;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	
}
