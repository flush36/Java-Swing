package Entity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import arquivo.EscreverArquivo;
import arquivo.LerArquivos;

public class Professor {

	private int matricula;
	private String nome;
	private String curso;
	private String especializacao;
	static List<Professor> listaProfessor = new ArrayList<Professor>();
	static EscreverArquivo arquivo = new EscreverArquivo();
	static LerArquivos ler = new LerArquivos();
	
	
	
	public Professor(int matricula, String nome, String curso, String especializacao) {
		this.matricula = matricula;
		this.nome = nome;
		this.curso = curso;
		this.especializacao = especializacao;
	}
	
	
	
	
	//Adiciona todos os cursos no txt
		public static void adicionaProfessores(Professor professor) throws IOException{
			if(!professor.equals("")){
				listaProfessor.add(professor);
				arquivo.EscreveEmProfessor(listaProfessor);
				listaProfessor.remove(professor);
				System.out.println("Dados adicionados com sucesso!");
			}else{
				System.out.println("Preencha os dados do professor.");
			}
		}
		
		//Lista todos os cursos no txt
		public static String ListarProfessores() throws IOException{
			return ler.LerEmProfessor();
		}
		
		
		//Buscar por ID
		public static String BuscarID(CharSequence id) throws IOException{
			if(ler.LerEmProfessor().contains(id)){
				System.out.println("Contem");
				return (String) id;
			}else {
				System.out.println("Nao contem o id que foi passado");
				return null;
			}
			
			
		}
		
		
		

	//ToString
	@Override
	public String toString() {
		return "Matricula: " + this.matricula + "   Nome: " + this.nome + "   Curso: " + this.curso
				+ "   Especializacao: " + this.especializacao;
	}
	
	

	// GETTERS AND SETTERS
	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getEspecializacao() {
		return especializacao;
	}

	public void setEspecializacao(String especializacao) {
		this.especializacao = especializacao;
	}

	public List<Professor> getListaProfessor() {
		return listaProfessor;
	}
	

}
