package arquivo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class LerArquivos {
	
	
	
	
	
	
	public String LerEmAluno() throws IOException {

		InputStream is = new FileInputStream("src/aluno.txt");
		InputStreamReader isr = new InputStreamReader(is, "UTF-8");
		BufferedReader br = new BufferedReader(isr);

		String textoArquivo = br.readLine();
		String recebe = "";
		while (textoArquivo != null) {
			
			textoArquivo = br.readLine();
			recebe = recebe + textoArquivo + " \n";
		}
		br.close();
		return recebe;
	}

	public String LerEmCurso() throws IOException {

		InputStream is = new FileInputStream("src/curso.txt");
		InputStreamReader isr = new InputStreamReader(is, "UTF-8");
		BufferedReader br = new BufferedReader(isr);

		String textoArquivo = br.readLine();
		String recebe = "";
		while (textoArquivo != null) {
			
			textoArquivo = br.readLine();
			recebe = recebe + textoArquivo + " \n";
		}
		br.close();
		return recebe;
	}

	public String LerEmProfessor() throws IOException {

		InputStream is = new FileInputStream("src/professor.txt");
		InputStreamReader isr = new InputStreamReader(is, "UTF-8");
		BufferedReader br = new BufferedReader(isr);
		
		String textoArquivo = br.readLine();
		String recebe = "";
		
		while (textoArquivo != null) {
			
			textoArquivo = br.readLine();
			recebe = recebe + textoArquivo + " \n";
		}
		br.close();
		return recebe;
	}

	
}
