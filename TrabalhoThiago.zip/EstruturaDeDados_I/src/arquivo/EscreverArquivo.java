package arquivo;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.List;

public class EscreverArquivo {

	
		
		public void EscreveEmAluno(List lista) throws IOException{

			OutputStream os = new FileOutputStream("src/aluno.txt", true);
			
			
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter bw = new BufferedWriter(osw);
			
			bw.newLine();
			bw.write(lista.toString());
			bw.close();
		}
		
		
		public void EscreveEmCurso(List lista) throws IOException{

			OutputStream os = new FileOutputStream("src/curso.txt", true);
			
			
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter bw = new BufferedWriter(osw);
			
			bw.newLine();
			bw.write(lista.toString());
			bw.close();
		}
		
		public void EscreveEmProfessor(List lista) throws IOException{

			OutputStream os = new FileOutputStream("src/professor.txt", true);
			
			
			OutputStreamWriter osw = new OutputStreamWriter(os);
			BufferedWriter bw = new BufferedWriter(osw);
			
			
			bw.newLine();
			bw.write(lista.toString());
			bw.close();
		}
			
			
		
	

}
